/**
 * 应用程序入口文件 - 初始化和协调应用程序功能
 * 
 * 该文件负责初始化事件监听器、处理用户交互、
 * 协调各个模块之间的通信。
 */

import { elements, selectedControlTime, originalData, currentPage, detectedDate, detectedDateSource, tableDisplayMode, updateVariables, equalAxisEnabled, toggleLineEnabled } from './config.js';
import { parseTime, formatDateTime, updateStatus } from './utils.js';
import { 
  handleDataFileUpload, 
  handleControlFileUpload, 
  confirmSheetSelection, 
  updateEncodingPreview, 
  confirmDataEncoding, 
  updateControlEncodingPreview, 
  confirmControlEncoding,
  updateUIAfterDataLoad,
  updateTable
} from './fileHandler.js';
import { 
  drawChart, 
  applyTimeRange, 
  resetTimeRange, 
  autoTimeRange, 
  exportChart, 
  exportData, 
  resetData, 
  clearAll, 
  toggleTable, 
  changePage, 
  jumpToPage
} from './chartHandler.js';

/**
 * 处理时间选择变化
 * @example
 * // 当用户更改时间选择器时调用
 * elements.timeSelectorSelect.addEventListener('change', handleTimeSelectChange);
 */
function handleTimeSelectChange() {
  const selectedTime = elements.timeSelectorSelect.value;
  updateVariables({
    selectedControlTime: selectedTime
  });
  
  // 更新时间范围选择器
  const parsedTime = parseTime(selectedTime);
  if (!isNaN(parsedTime)) {
    const endTime = parsedTime + 15 * 60 * 1000; // 15分钟
    elements.timeRangeStart.value = formatDateTime(parsedTime);
    elements.timeRangeEnd.value = formatDateTime(endTime);
    
    // 自动应用时间范围到拖动条
    applyTimeRange();
  }
}

/**
 * 根据控制文件时间过滤数据
 * @example
 * // 当用户点击根据控制文件过滤按钮时调用
 * elements.filterByControlBtn.addEventListener('click', filterDataByControlTime);
 */
function filterDataByControlTime() {
  if (!selectedControlTime || originalData.length === 0) return;
  
  const selectedTime = parseTime(selectedControlTime);
  if (isNaN(selectedTime)) return;
  
  const endTime = selectedTime + 15 * 60 * 1000; // 15分钟
  
  const newFilteredData = originalData.filter(row => {
    const rowTime = parseTime(row[0]);
    return !isNaN(rowTime) && rowTime >= selectedTime && rowTime <= endTime;
  });
  
  // 更新全局变量
  updateVariables({
    filteredData: newFilteredData
  });
  
  // 更新时间范围选择器
  if (newFilteredData.length > 0) {
    const firstTime = parseTime(newFilteredData[0][0]);
    const lastTime = parseTime(newFilteredData[newFilteredData.length - 1][0]);
    
    if (!isNaN(firstTime) && !isNaN(lastTime)) {
      elements.timeRangeStart.value = formatDateTime(firstTime);
      elements.timeRangeEnd.value = formatDateTime(lastTime);
    }
  }
  
  updateUIAfterDataLoad();
  updateStatus(`✅ 已根据控制文件时间筛选数据，共 ${newFilteredData.length} 条记录`);
}

/**
 * 处理每页显示行数变化
 * @example
 * // 当用户更改每页显示行数时调用
 * elements.pageSizeSelect.addEventListener('change', handlePageSizeChange);
 */
function handlePageSizeChange() {
  const newPageSize = parseInt(elements.pageSizeSelect.value);
  if (!isNaN(newPageSize)) {
    updateVariables({
      itemsPerPage: newPageSize,
      currentPage: 1 // 重置为第一页
    });
    updateUIAfterDataLoad();
  }
}

/**
 * 清除左侧Y轴选择
 * @example
 * // 当用户点击清除左侧Y轴按钮时调用
 * elements.clearYAxisBtn.addEventListener('click', clearYAxisSelection);
 */
function clearYAxisSelection() {
  // 清除所有选中项
  Array.from(elements.yAxisSelect.options).forEach(option => {
    option.selected = false;
  });
  // 更新全局变量
  updateVariables({
    yAxisIndices: []
  });
  updateStatus('✅ 已清除左侧Y轴选择');
}

/**
 * 清除右侧Y轴选择
 * @example
 * // 当用户点击清除右侧Y轴按钮时调用
 * elements.clearYAxis2Btn.addEventListener('click', clearYAxis2Selection);
 */
function clearYAxis2Selection() {
  // 清除所有选中项
  Array.from(elements.yAxis2Select.options).forEach(option => {
    option.selected = false;
  });
  // 更新全局变量
  updateVariables({
    yAxis2Indices: []
  });
  updateStatus('✅ 已清除右侧Y轴选择');
}

/**
 * 全选左侧Y轴
 * @example
 * // 当用户点击全选左侧Y轴按钮时调用
 * elements.selectAllYAxisBtn.addEventListener('click', selectAllYAxis);
 */
function selectAllYAxis() {
  // 获取右侧Y轴已选中的列索引
  const rightSelectedIndices = Array.from(elements.yAxis2Select.options)
    .filter(option => option.selected)
    .map(option => parseInt(option.value))
    .filter(index => !isNaN(index));
  
  // 只选择左侧Y轴中那些不在右侧Y轴选中列表中的列
  const options = Array.from(elements.yAxisSelect.options);
  const selectedIndices = options.map((option, index) => {
    const value = parseInt(option.value);
    if (!isNaN(value) && !rightSelectedIndices.includes(value)) {
      option.selected = true;
      return value;
    } else {
      option.selected = false;
      return null;
    }
  }).filter(index => index !== null);
  
  // 更新全局变量
  updateVariables({
    yAxisIndices: selectedIndices
  });
  updateStatus('✅ 已全选左侧Y轴所有未在右侧Y轴选中的数据列');
}

/**
 * 全选右侧Y轴
 * @example
 * // 当用户点击全选右侧Y轴按钮时调用
 * elements.selectAllYAxis2Btn.addEventListener('click', selectAllYAxis2);
 */
function selectAllYAxis2() {
  // 获取左侧Y轴已选中的列索引
  const leftSelectedIndices = Array.from(elements.yAxisSelect.options)
    .filter(option => option.selected)
    .map(option => parseInt(option.value))
    .filter(index => !isNaN(index));
  
  // 只选择右侧Y轴中那些不在左侧Y轴选中列表中的列
  const options = Array.from(elements.yAxis2Select.options);
  const selectedIndices = options.map((option, index) => {
    const value = parseInt(option.value);
    if (!isNaN(value) && !leftSelectedIndices.includes(value)) {
      option.selected = true;
      return value;
    } else {
      option.selected = false;
      return null;
    }
  }).filter(index => index !== null);
  
  // 更新全局变量
  updateVariables({
    yAxis2Indices: selectedIndices
  });
  updateStatus('✅ 已全选右侧Y轴所有未在左侧Y轴选中的数据列');
}

/**
 * 处理自动设置时间范围
 * @example
 * // 当用户点击自动设置时间范围按钮时调用
 * elements.autoTimeRangeBtn.addEventListener('click', handleAutoTimeRange);
 */
function handleAutoTimeRange() {
  autoTimeRange();
  applyTimeRange();
  updateStatus('✅ 已自动设置时间范围');
}

/**
 * 切换整齐坐标轴模式
 * 当X轴为数值类型时，切换是否使用等值坐标间距
 */
function toggleEqualAxis() {
  const newValue = !equalAxisEnabled;
  updateVariables({ equalAxisEnabled: newValue });
  if (newValue) {
    elements.equalAxisBtn.classList.remove('btn-outline-info');
    elements.equalAxisBtn.classList.add('btn-info');
    elements.equalAxisBtn.textContent = '✅ 整齐坐标轴';
    updateStatus('✅ 已开启整齐坐标轴模式');
  } else {
    elements.equalAxisBtn.classList.remove('btn-info');
    elements.equalAxisBtn.classList.add('btn-outline-info');
    elements.equalAxisBtn.textContent = '📐 整齐坐标轴';
    updateStatus('ℹ️ 已关闭整齐坐标轴模式');
  }
  // 重新绘制图表
  drawChart();
}

/**
 * 切换去掉连线模式
 * 切换是否显示数据点之间的连线
 */
function toggleLineMode() {
  const newValue = !toggleLineEnabled;
  updateVariables({ toggleLineEnabled: newValue });
  if (newValue) {
    elements.toggleLineBtn.classList.remove('btn-outline-warning');
    elements.toggleLineBtn.classList.add('btn-warning');
    elements.toggleLineBtn.textContent = '✅ 去掉连线';
    updateStatus('✅ 已开启只显示数据点模式');
  } else {
    elements.toggleLineBtn.classList.remove('btn-warning');
    elements.toggleLineBtn.classList.add('btn-outline-warning');
    elements.toggleLineBtn.textContent = '🔗 去掉连线';
    updateStatus('ℹ️ 已关闭只显示数据点模式');
  }
  // 重新绘制图表
  drawChart();
}

/**
 * 显示日期修改输入框
 */
function showDateEdit() {
  if (elements.detectedDateEdit) {
    elements.detectedDateEdit.classList.remove('d-none');
  }
  if (elements.editDetectedDateBtn) {
    elements.editDetectedDateBtn.classList.add('d-none');
  }
}

/**
 * 隐藏日期修改输入框
 */
function hideDateEdit() {
  if (elements.detectedDateEdit) {
    elements.detectedDateEdit.classList.add('d-none');
  }
  if (elements.editDetectedDateBtn) {
    elements.editDetectedDateBtn.classList.remove('d-none');
  }
}

/**
 * 确认修改日期
 */
function confirmDateEdit() {
  const newDate = elements.detectedDateInput.value;
  if (newDate) {
    updateVariables({
      detectedDate: newDate,
      detectedDateSource: '手动设置'
    });
    updateStatus(`✅ 日期已修改为：${newDate}`);
    // 更新显示
    if (elements.detectedDateSource) {
      elements.detectedDateSource.textContent = '来源：手动设置';
    }
    if (elements.detectedDateValue) {
      elements.detectedDateValue.textContent = `识别日期：${newDate}`;
    }
    // 重新绘制图表
    drawChart();
  }
  hideDateEdit();
}

/**
 * 取消修改日期
 */
function cancelDateEdit() {
  // 恢复原来的日期值
  if (elements.detectedDateInput) {
    elements.detectedDateInput.value = detectedDate || '';
  }
  hideDateEdit();
}

/**
 * 切换表格显示模式
 * @param {'raw' | 'processed'} mode - 显示模式
 */
function switchTableDisplayMode(mode) {
  updateVariables({
    tableDisplayMode: mode,
    currentPage: 1 // 切换模式时重置到第一页
  });
  
  // 更新按钮状态
  if (mode === 'raw') {
    elements.showRawDataBtn.classList.add('active');
    elements.showProcessedDataBtn.classList.remove('active');
    updateStatus('✅ 表格已切换为原始数据显示模式');
  } else {
    elements.showProcessedDataBtn.classList.add('active');
    elements.showRawDataBtn.classList.remove('active');
    updateStatus('✅ 表格已切换为处理后数据显示模式');
  }
  
  // 重新更新表格
  updateTable();
}

/**
 * 初始化事件监听器
 * @example
 * initEventListeners();
 */
function initEventListeners() {
  // 数据文件上传
  elements.dataFileInput.addEventListener('change', handleDataFileUpload);
  
  // 控制文件上传
  elements.controlFileInput.addEventListener('change', handleControlFileUpload);
  
  // 编码选择
  elements.dataFileEncoding.addEventListener('change', function() {
    updateEncodingPreview();
    confirmDataEncoding();
  });
  elements.confirmEncodingBtn.addEventListener('click', confirmDataEncoding);
  
  elements.controlFileEncoding.addEventListener('change', function() {
    updateControlEncodingPreview();
    confirmControlEncoding();
  });
  elements.confirmControlEncodingBtn.addEventListener('click', confirmControlEncoding);
  
  // 时间选择
  elements.timeSelectorSelect.addEventListener('change', handleTimeSelectChange);
  elements.filterByControlBtn.addEventListener('click', filterDataByControlTime);
  
  // 坐标轴选择
  elements.drawChartBtn.addEventListener('click', drawChart);
  elements.clearYAxisBtn.addEventListener('click', clearYAxisSelection);
  elements.clearYAxis2Btn.addEventListener('click', clearYAxis2Selection);
  elements.selectAllYAxisBtn.addEventListener('click', selectAllYAxis);
  elements.selectAllYAxis2Btn.addEventListener('click', selectAllYAxis2);
  
  // X轴选择器变化时更新时间范围
  elements.xAxisSelect.addEventListener('change', function() {
    // 重新自动设置时间范围
    autoTimeRange();
  });
  
  // 数据文件手动选择编码checkbox事件
  elements.manualEncoding.addEventListener('change', function() {
    if (this.checked) {
      // 显示编码选择器
      elements.encodingSelector.classList.remove('d-none');
      // 如果已经选择了文件，更新编码预览
      if (elements.dataFileInput.files.length > 0) {
        updateEncodingPreview();
      }
    } else {
      // 隐藏编码选择器
      elements.encodingSelector.classList.add('d-none');
    }
  });
  
  // 控制文件手动选择编码checkbox事件
  elements.manualControlEncoding.addEventListener('change', function() {
    if (this.checked) {
      // 显示编码选择器
      elements.controlEncodingSelector.classList.remove('d-none');
      // 如果已经选择了文件，更新编码预览
      if (elements.controlFileInput.files.length > 0) {
        updateControlEncodingPreview();
      }
    } else {
      // 隐藏编码选择器
      elements.controlEncodingSelector.classList.add('d-none');
    }
  });
  
  // 时间范围选择
  elements.applyTimeRangeBtn.addEventListener('click', applyTimeRange);
  elements.resetTimeRangeBtn.addEventListener('click', resetTimeRange);
  elements.autoTimeRangeBtn.addEventListener('click', handleAutoTimeRange);
  elements.equalAxisBtn.addEventListener('click', toggleEqualAxis);
  
  // 操作按钮
  elements.exportChartBtn.addEventListener('click', exportChart);
  elements.exportDataBtn.addEventListener('click', exportData);
  elements.toggleLineBtn.addEventListener('click', toggleLineMode);
  elements.resetDataBtn.addEventListener('click', resetData);
  elements.clearAllBtn.addEventListener('click', clearAll);
  
  // 表格控制
  elements.toggleTableBtn.addEventListener('click', toggleTable);
  elements.prevPageBtn.addEventListener('click', () => changePage(currentPage - 1));
  elements.nextPageBtn.addEventListener('click', () => changePage(currentPage + 1));
  elements.jumpBtn.addEventListener('click', jumpToPage);
  elements.pageSizeSelect.addEventListener('change', handlePageSizeChange);
  
  // 表格显示模式切换
  elements.showRawDataBtn.addEventListener('click', () => switchTableDisplayMode('raw'));
  elements.showProcessedDataBtn.addEventListener('click', () => switchTableDisplayMode('processed'));
  
  // Excel工作表选择
  elements.confirmSheetBtn.addEventListener('click', confirmSheetSelection);
  
  // 日期修改按钮事件
  if (elements.editDetectedDateBtn) {
    elements.editDetectedDateBtn.addEventListener('click', showDateEdit);
  }
  if (elements.confirmDetectedDateBtn) {
    elements.confirmDetectedDateBtn.addEventListener('click', confirmDateEdit);
  }
  if (elements.cancelDetectedDateBtn) {
    elements.cancelDetectedDateBtn.addEventListener('click', cancelDateEdit);
  }
}

/**
 * 初始化应用
 * @example
 * initApp();
 */
function initApp() {
  initEventListeners();
  updateStatus('📋 请先上传DemDec数据文件（左侧），可选上传DemControl时间筛选文件（右侧）');
}

// 当DOM加载完成后初始化应用
document.addEventListener('DOMContentLoaded', initApp);